import {createContext} from 'react'
export const ProductContex = createContext();