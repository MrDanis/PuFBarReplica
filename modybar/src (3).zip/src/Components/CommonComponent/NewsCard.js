import React from 'react'

const NewsCard = () => {
  return (
    <div>NewsCard</div>
  )
}

export default NewsCard