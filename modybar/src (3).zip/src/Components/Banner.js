import React from 'react'

const Banner = () => {
  return (
    <div className='conatiner-fluid m-0 p-0 border border-2 border-dark '>
        <div className='row m-0 p-0  border border-2 border-danger'>
            <div className='col-12 m-0 p-0 border border-2 border-danger'>
                {/* <img className='img-fluid w-100 m-0 p-0' src='./Bannerblack.png' alt='test'></img> */}
            </div>
        </div>
    </div>
  )
}

export default Banner