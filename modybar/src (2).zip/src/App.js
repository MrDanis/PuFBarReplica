import Index from './Routes/Index';
import React,{useEffect,useState} from 'react'
function App() {
  useEffect(() => {
    // 3
    var vSearchStr={
  
      branch_id : 2,
     
      
   }
     fetch("http://74.208.115.190:80/4DACTION/AjerWebProductsCatsCallingUp",{
       method:"POST",
       'Content-Type':"application/json",
       body: JSON.stringify(vSearchStr)
     }).then(res=>res.json()).then((res)=>{
       console.log("3:AjerWebProductsCatsCallingUp",res)
     }) .catch(function (error) {
      alert('Please Enter Valid Email or Password');
      // setloading(false);
    });
    //4
    var vSearchStr={
    
      branch_id : 2,
      client_id:"",
      item_code:"",
      item_name:"",
      category_id:0
   
      
   }
     fetch("http://74.208.115.190:80/4DACTION/AjerWebProductsListCallingUp",{
       method:"POST",
       'Content-Type':"application/json",
       body: JSON.stringify(vSearchStr)
     }).then(res=>res.json()).then((res)=>{
      console.log("4:AjerWebProductsListCallingUp",res)


       
     }) .catch(function (error) {
      alert('Please Enter Valid Email or Password');
      // setloading(false);
    });
    //5
//     var vSearchStr1={
//       system_id :[353]
  
// }
//  fetch("http://74.208.115.190:80/4DACTION/AjerSingleProductsDetailsCallsUp",{
//    method:"POST",
//    'Content-Type':"application/json",
//    body: JSON.stringify(vSearchStr1)
//  }).then(res=>res.json()).then((res)=>{
//   console.log("5:AjerSingleProductsDetailsCallsUp",res)

//  })
//  .catch(function (error) {
//   console.log("5 Error:AjerSingleProductsDetailsCallsUp",error)

//   // setloading(false);
// });
//6

    //       var vSearchStr1={
    //         ArrayProductsID :[353,340,369,357]
        
    //  }
    //    fetch("http://74.208.115.190:80/4DACTION/AjerMultiProductsDetailsCallsUp",{
    //      method:"POST",
    //      'Content-Type':"application/json",
    //      body: JSON.stringify(vSearchStr1)
    //    }).then(res=>res.json()).then((res)=>{
    //     console.log("6:AjerMultiProductsDetailsCallsUp",res)

    //    })
    //    .catch(function (error) {
    //     // alert('Please Enter Valid Email or Password');
    //     console.log("6 Error:AjerMultiProductsDetailsCallsUp",error)
    //     // setloading(false);
    //   });

  },[]);
  return (
   <Index></Index>
  );
}

export default App;
