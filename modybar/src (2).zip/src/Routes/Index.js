import React from 'react'
import Public from './Public'
const Index = () => {
  return (
    <Public></Public>
  )
}

export default Index