import React from 'react'

const CommonButton = () => {
  return (
    <div>CommonButton</div>
  )
}

export default CommonButton