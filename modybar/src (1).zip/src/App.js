import Index from './Routes/Index';
function App() {
  return (
   <Index></Index>
  );
}

export default App;
